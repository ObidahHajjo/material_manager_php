<?php require 'shared_error_layout.php'; ?>
<?php
$title = "Validation Error";
$heading = "Invalid input";
?>
