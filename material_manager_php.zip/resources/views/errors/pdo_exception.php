<?php require 'shared_error_layout.php'; ?>
<?php
$title = "Database Error";
$heading = "Database connection failed";
?>
