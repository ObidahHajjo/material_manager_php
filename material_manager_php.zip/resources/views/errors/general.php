<?php require 'shared_error_layout.php'; ?>
<?php
$title = "Application Error";
$heading = "An unexpected error occurred";
?>
