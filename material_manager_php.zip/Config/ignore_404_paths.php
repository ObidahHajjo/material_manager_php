<?php

return [
    "favicon"
];
